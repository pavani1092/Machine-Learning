I wrote the program in python 3.6.3.
Open terminal and type 
>> python EM.py
This program will compute following things.
1. Loglikelihood vs. Iterations. You will not see any plot as it is saved as images namely Train_plot.png and Test_plot.png.
    They are saved under the working directory and contains Iteration vs. Loglikelihood plots of Training data and Test Data respectively.
2. Performs 10 runs of the algorithm with different seeds. Plot is saved in Run_plot.png
3. Performs cluster assignments for the training data after first run. Accuracy is reported. More details can be found in the .pdf report.
4. Runs the algorithm with 10 different clusters (1 - 10). Saves the plot in Cluster_plot.png

After program exits under your working directory all the plots can be found saved. I repeat no plot will be shown as all will be saved under the working directory.     
